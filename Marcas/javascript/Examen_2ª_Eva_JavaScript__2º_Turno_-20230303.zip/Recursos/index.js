
	function enviar() {		
		if (comprobaciones) {
			/*se envía el formulario*/
		}
		else {
			/*la siguiente línea evita el envío del submit*/
			event.preventDefault();
			}
	}
